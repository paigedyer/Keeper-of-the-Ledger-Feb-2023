Hi! Welcome to my very in progress text based game Keeper of the Ledger.

Run the batch file and it should open in console.

Make sure u have Java installed!